import GRN from '../models/GRN.js';
import Stock from '../models/Stock.js';
import StockTransaction from '../models/StockTransaction.js';
import Sequence from '../models/Sequence.js';

// Generate GRN number
const generateGRNNumber = async (year) => {
  const sequence = await Sequence.findOneAndUpdate(
    { year, type: 'GRN' },
    { $inc: { seq: 1 } },
    { new: true, upsert: true }
  );
  return `GRN-${year}-${String(sequence.seq).padStart(4, '0')}`;
};

// Get all GRNs
export const getAllGRNs = async (req, res) => {
  try {
    const { status, supplier, startDate, endDate, search } = req.query;
    let query = {};

    if (status) {
      query.status = status;
    }

    if (supplier) {
      query.supplier = supplier;
    }

    if (startDate || endDate) {
      query.grnDate = {};
      if (startDate) query.grnDate.$gte = new Date(startDate);
      if (endDate) query.grnDate.$lte = new Date(endDate);
    }

    if (search) {
      query.$or = [
        { grnNumber: { $regex: search, $options: 'i' } },
        { 'purchaseOrder.poNumber': { $regex: search, $options: 'i' } },
        { 'invoiceDetails.invoiceNumber': { $regex: search, $options: 'i' } }
      ];
    }

    const grns = await GRN.find(query)
      .populate('supplier', 'name email phone')
      .populate('items.product', 'name category')
      .populate('createdBy', 'name email')
      .populate('inspectedBy', 'name email')
      .populate('approvedBy', 'name email')
      .sort({ grnDate: -1 });

    res.json(grns);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching GRNs', error: error.message });
  }
};

// Get single GRN
export const getGRNById = async (req, res) => {
  try {
    const { id } = req.params;
    const grn = await GRN.findById(id)
      .populate('supplier', 'name email phone address')
      .populate('items.product', 'name category price')
      .populate('createdBy', 'name email')
      .populate('inspectedBy', 'name email')
      .populate('approvedBy', 'name email')
      .populate('purchaseOrder.poRef');

    if (!grn) {
      return res.status(404).json({ message: 'GRN not found' });
    }

    res.json(grn);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching GRN', error: error.message });
  }
};

// Create GRN
export const createGRN = async (req, res) => {
  try {
    const { 
      purchaseOrder, 
      supplier, 
      grnDate, 
      deliveryNote, 
      items, 
      location, 
      notes 
    } = req.body;

    const year = new Date(grnDate || Date.now()).getFullYear();
    const grnNumber = await generateGRNNumber(year);

    const grn = new GRN({
      grnNumber,
      purchaseOrder,
      supplier,
      grnDate: grnDate || Date.now(),
      deliveryNote,
      items: items.map(item => ({
        ...item,
        acceptedQuantity: item.acceptedQuantity || item.receivedQuantity,
        rejectedQuantity: item.rejectedQuantity || 0,
        shortQuantity: (item.orderedQuantity || 0) - (item.receivedQuantity || 0)
      })),
      location: location || 'Main Warehouse',
      notes,
      status: 'draft',
      createdBy: req.user.id
    });

    await grn.save();
    const populatedGRN = await GRN.findById(grn._id)
      .populate('supplier', 'name email phone')
      .populate('items.product', 'name category')
      .populate('createdBy', 'name email');

    res.status(201).json(populatedGRN);
  } catch (error) {
    res.status(500).json({ message: 'Error creating GRN', error: error.message });
  }
};

// Update GRN
export const updateGRN = async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;

    const grn = await GRN.findById(id);
    if (!grn) {
      return res.status(404).json({ message: 'GRN not found' });
    }

    // Prevent updates if already completed
    if (grn.status === 'completed' && !req.user.role === 'admin') {
      return res.status(403).json({ message: 'Cannot modify completed GRN' });
    }

    Object.assign(grn, updates);
    await grn.save();

    const updatedGRN = await GRN.findById(id)
      .populate('supplier', 'name email phone')
      .populate('items.product', 'name category')
      .populate('createdBy', 'name email')
      .populate('inspectedBy', 'name email')
      .populate('approvedBy', 'name email');

    res.json(updatedGRN);
  } catch (error) {
    res.status(500).json({ message: 'Error updating GRN', error: error.message });
  }
};

// Perform quality inspection
export const inspectGRN = async (req, res) => {
  try {
    const { id } = req.params;
    const { items, qualityStatus, inspectionNotes } = req.body;

    const grn = await GRN.findById(id);
    if (!grn) {
      return res.status(404).json({ message: 'GRN not found' });
    }

    if (grn.status !== 'draft') {
      return res.status(400).json({ message: 'GRN is not in draft status' });
    }

    // Update items with inspection results
    if (items && items.length > 0) {
      grn.items = items.map((item, index) => ({
        ...grn.items[index].toObject(),
        ...item
      }));
    }

    grn.qualityStatus = qualityStatus || 'passed';
    grn.status = 'inspected';
    grn.inspectedBy = req.user.id;
    
    if (inspectionNotes) {
      grn.notes = grn.notes ? `${grn.notes}\n\nInspection: ${inspectionNotes}` : inspectionNotes;
    }

    await grn.save();

    const updatedGRN = await GRN.findById(id)
      .populate('supplier', 'name email phone')
      .populate('items.product', 'name category')
      .populate('inspectedBy', 'name email');

    res.json(updatedGRN);
  } catch (error) {
    res.status(500).json({ message: 'Error inspecting GRN', error: error.message });
  }
};

// Approve GRN
export const approveGRN = async (req, res) => {
  try {
    const { id } = req.params;

    const grn = await GRN.findById(id);
    if (!grn) {
      return res.status(404).json({ message: 'GRN not found' });
    }

    if (grn.status !== 'inspected') {
      return res.status(400).json({ message: 'GRN must be inspected before approval' });
    }

    grn.status = 'approved';
    grn.approvedBy = req.user.id;
    await grn.save();

    const updatedGRN = await GRN.findById(id)
      .populate('supplier', 'name email phone')
      .populate('items.product', 'name category')
      .populate('approvedBy', 'name email');

    res.json(updatedGRN);
  } catch (error) {
    res.status(500).json({ message: 'Error approving GRN', error: error.message });
  }
};

// Update stock from GRN (post goods to inventory)
export const updateStockFromGRN = async (req, res) => {
  try {
    const { id } = req.params;

    const grn = await GRN.findById(id).populate('items.product');
    if (!grn) {
      return res.status(404).json({ message: 'GRN not found' });
    }

    if (grn.status !== 'approved') {
      return res.status(400).json({ message: 'GRN must be approved before updating stock' });
    }

    if (grn.stockUpdated) {
      return res.status(400).json({ message: 'Stock already updated for this GRN' });
    }

    // Update stock for each item
    const stockUpdates = [];
    const transactions = [];

    for (const item of grn.items) {
      if (item.acceptedQuantity > 0) {
        // Find or create stock record
        let stock = await Stock.findOne({ product: item.product._id });
        
        if (!stock) {
          stock = new Stock({
            product: item.product._id,
            quantity: 0,
            location: grn.location,
            batchTracking: !!item.batchNumber,
            serialTracking: item.serialNumbers && item.serialNumbers.length > 0
          });
        }

        const balanceBefore = stock.quantity;
        stock.quantity += item.acceptedQuantity;
        const balanceAfter = stock.quantity;
        stock.lastRestockDate = new Date();

        // Add batch information if provided
        if (item.batchNumber) {
          stock.batches.push({
            batchNumber: item.batchNumber,
            quantity: item.acceptedQuantity,
            expiryDate: item.expiryDate,
            manufactureDate: item.manufactureDate,
            notes: item.inspectionNotes
          });
        }

        // Add serial numbers if provided
        if (item.serialNumbers && item.serialNumbers.length > 0) {
          item.serialNumbers.forEach(sn => {
            stock.serialNumbers.push({
              serialNumber: sn,
              status: 'available',
              location: grn.location
            });
          });
        }

        await stock.save();
        stockUpdates.push(stock);

        // Create stock transaction
        const transaction = new StockTransaction({
          transactionType: 'grn',
          product: item.product._id,
          quantity: item.acceptedQuantity,
          toLocation: grn.location,
          batchNumber: item.batchNumber,
          serialNumbers: item.serialNumbers,
          balanceBefore,
          balanceAfter,
          referenceType: 'GRN',
          referenceId: grn._id,
          referenceNumber: grn.grnNumber,
          unitPrice: item.unitPrice,
          totalValue: item.acceptedQuantity * (item.unitPrice || 0),
          notes: `GRN stock update - ${item.acceptedQuantity} units received`,
          performedBy: req.user.id,
          approvedBy: grn.approvedBy,
          transactionDate: grn.grnDate
        });

        await transaction.save();
        transactions.push(transaction);
      }
    }

    // Mark GRN as completed and stock updated
    grn.stockUpdated = true;
    grn.status = 'completed';
    await grn.save();

    res.json({
      message: 'Stock updated successfully',
      grn,
      stockUpdates,
      transactions
    });
  } catch (error) {
    res.status(500).json({ message: 'Error updating stock from GRN', error: error.message });
  }
};

// Match invoice with GRN
export const matchInvoice = async (req, res) => {
  try {
    const { id } = req.params;
    const { invoiceNumber, invoiceDate, invoiceAmount } = req.body;

    const grn = await GRN.findById(id);
    if (!grn) {
      return res.status(404).json({ message: 'GRN not found' });
    }

    grn.invoiceDetails = {
      invoiceNumber,
      invoiceDate,
      invoiceAmount,
      matched: true
    };

    await grn.save();

    const updatedGRN = await GRN.findById(id)
      .populate('supplier', 'name email phone')
      .populate('items.product', 'name category');

    res.json(updatedGRN);
  } catch (error) {
    res.status(500).json({ message: 'Error matching invoice', error: error.message });
  }
};

// Delete GRN (only draft status)
export const deleteGRN = async (req, res) => {
  try {
    const { id } = req.params;

    const grn = await GRN.findById(id);
    if (!grn) {
      return res.status(404).json({ message: 'GRN not found' });
    }

    if (grn.status !== 'draft') {
      return res.status(400).json({ message: 'Can only delete draft GRNs' });
    }

    await GRN.findByIdAndDelete(id);
    res.json({ message: 'GRN deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting GRN', error: error.message });
  }
};

// Get GRN reports/statistics
export const getGRNReports = async (req, res) => {
  try {
    const { startDate, endDate, supplier } = req.query;
    let query = {};

    if (startDate || endDate) {
      query.grnDate = {};
      if (startDate) query.grnDate.$gte = new Date(startDate);
      if (endDate) query.grnDate.$lte = new Date(endDate);
    }

    if (supplier) {
      query.supplier = supplier;
    }

    const grns = await GRN.find(query)
      .populate('supplier', 'name')
      .populate('items.product', 'name category');

    // Calculate statistics
    const stats = {
      totalGRNs: grns.length,
      byStatus: {
        draft: grns.filter(g => g.status === 'draft').length,
        inspected: grns.filter(g => g.status === 'inspected').length,
        approved: grns.filter(g => g.status === 'approved').length,
        completed: grns.filter(g => g.status === 'completed').length,
        rejected: grns.filter(g => g.status === 'rejected').length
      },
      byQuality: {
        passed: grns.filter(g => g.qualityStatus === 'passed').length,
        failed: grns.filter(g => g.qualityStatus === 'failed').length,
        partial: grns.filter(g => g.qualityStatus === 'partial').length,
        pending: grns.filter(g => g.qualityStatus === 'pending').length
      },
      totalValue: grns.reduce((sum, grn) => sum + (grn.totalValue || 0), 0),
      totalItems: grns.reduce((sum, grn) => {
        return sum + grn.items.reduce((itemSum, item) => itemSum + item.acceptedQuantity, 0);
      }, 0),
      rejectedItems: grns.reduce((sum, grn) => {
        return sum + grn.items.reduce((itemSum, item) => itemSum + (item.rejectedQuantity || 0), 0);
      }, 0),
      shortItems: grns.reduce((sum, grn) => {
        return sum + grn.items.reduce((itemSum, item) => itemSum + (item.shortQuantity || 0), 0);
      }, 0)
    };

    res.json({ stats, grns });
  } catch (error) {
    res.status(500).json({ message: 'Error generating reports', error: error.message });
  }
};