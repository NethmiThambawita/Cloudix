import express from 'express';
import {
  getAllGRNs,
  getGRNById,
  createGRN,
  updateGRN,
  inspectGRN,
  approveGRN,
  updateStockFromGRN,
  matchInvoice,
  deleteGRN,
  getGRNReports
} from '../controllers/grn.controller.js';
import { authenticateToken } from '../middleware/auth.js';
import { authorize } from '../middleware/authorize.js';

const router = express.Router();

// All routes require authentication
router.use(authenticateToken);

// Get all GRNs
router.get('/', getAllGRNs);

// Get GRN reports/statistics
router.get('/reports', getGRNReports);

// Get single GRN by ID
router.get('/:id', getGRNById);

// Create new GRN (admin/manager only)
router.post('/', authorize(['admin', 'manager']), createGRN);

// Update GRN (admin/manager only)
router.put('/:id', authorize(['admin', 'manager']), updateGRN);

// Perform quality inspection (admin/manager only)
router.post('/:id/inspect', authorize(['admin', 'manager']), inspectGRN);

// Approve GRN (admin/manager only)
router.post('/:id/approve', authorize(['admin', 'manager']), approveGRN);

// Update stock from GRN (admin/manager only)
router.post('/:id/update-stock', authorize(['admin', 'manager']), updateStockFromGRN);

// Match invoice with GRN (admin/manager only)
router.post('/:id/match-invoice', authorize(['admin', 'manager']), matchInvoice);

// Delete GRN (admin only)
router.delete('/:id', authorize(['admin']), deleteGRN);

export default router;