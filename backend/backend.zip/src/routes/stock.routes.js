import express from 'express';
import {
  getAllStock,
  getStockByProduct,
  createStock,
  updateStock,
  adjustStock,
  transferStock,
  getStockTransactions,
  getLowStockAlerts,
  getStockBalance
} from '../controllers/stock.controller.js';
import { authenticateToken } from '../middleware/auth.js';
import { authorize } from '../middleware/authorize.js';

const router = express.Router();

// All routes require authentication
router.use(authenticateToken);

// Get all stock items
router.get('/', getAllStock);

// Get low stock alerts
router.get('/alerts', getLowStockAlerts);

// Get stock transactions/history
router.get('/transactions', getStockTransactions);

// Get stock by product ID
router.get('/product/:productId', getStockByProduct);

// Get stock balance for a product
router.get('/balance/:productId', getStockBalance);

// Create new stock entry (admin/manager only)
router.post('/', authorize(['admin', 'manager']), createStock);

// Update stock settings (admin/manager only)
router.put('/:id', authorize(['admin', 'manager']), updateStock);

// Stock adjustment (admin/manager only)
router.post('/adjust', authorize(['admin', 'manager']), adjustStock);

// Stock transfer (admin/manager only)
router.post('/transfer', authorize(['admin', 'manager']), transferStock);

export default router;